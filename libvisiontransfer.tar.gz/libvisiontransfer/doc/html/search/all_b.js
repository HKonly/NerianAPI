var searchData=
[
  ['operationmode',['OperationMode',['../classvisiontransfer_1_1DeviceParameters.html#ab70aa27a776bc19fc81e9b63016ab700',1,'visiontransfer::DeviceParameters']]],
  ['operator_3d_3d',['operator==',['../classvisiontransfer_1_1DeviceInfo.html#a516e439fe0222342c95a69d45cc6b0ea',1,'visiontransfer::DeviceInfo']]]
];
