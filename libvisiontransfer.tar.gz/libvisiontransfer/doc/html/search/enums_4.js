var searchData=
[
  ['targetframe',['TargetFrame',['../classvisiontransfer_1_1DeviceParameters.html#ae1d20a87d9e1eee7d08f4c5fd03cde02',1,'visiontransfer::DeviceParameters']]],
  ['transferstatus',['TransferStatus',['../classvisiontransfer_1_1ImageTransfer.html#ab3580eab2dae0695d353cf6626d5e5a7',1,'visiontransfer::ImageTransfer']]]
];
