var searchData=
[
  ['handlemessage',['handleMessage',['../classvisiontransfer_1_1internal_1_1ClientSideDataChannelIMUBNO080.html#a4c2d6d888320d33acad26f54fa128d89',1,'visiontransfer::internal::ClientSideDataChannelIMUBNO080::handleMessage()'],['../classvisiontransfer_1_1internal_1_1DataChannel.html#a910d918d22f27a4ce20e1c4d7b1a780f',1,'visiontransfer::internal::DataChannel::handleMessage()']]],
  ['hasimagetype',['hasImageType',['../classvisiontransfer_1_1ImageSet.html#afa7ddacc61ac44d85be69b7e08aa0fb3',1,'visiontransfer::ImageSet']]],
  ['headerpreamble',['HeaderPreamble',['../structvisiontransfer_1_1internal_1_1DataBlockProtocol_1_1HeaderPreamble.html',1,'visiontransfer::internal::DataBlockProtocol']]]
];
