var searchData=
[
  ['format_5f12_5fbit_5fmono',['FORMAT_12_BIT_MONO',['../classvisiontransfer_1_1ImageSet.html#a01f3573d250c4dcee32809375b28abbaac66400763b3f207368632057a08608c0',1,'visiontransfer::ImageSet']]],
  ['format_5f8_5fbit_5fmono',['FORMAT_8_BIT_MONO',['../classvisiontransfer_1_1ImageSet.html#a01f3573d250c4dcee32809375b28abbaa522b31d1246edc60b776a6b7a61be7e2',1,'visiontransfer::ImageSet']]],
  ['format_5f8_5fbit_5frgb',['FORMAT_8_BIT_RGB',['../classvisiontransfer_1_1ImageSet.html#a01f3573d250c4dcee32809375b28abbaa16c783bc33fbe0b9daf03760c2e52af4',1,'visiontransfer::ImageSet']]]
];
