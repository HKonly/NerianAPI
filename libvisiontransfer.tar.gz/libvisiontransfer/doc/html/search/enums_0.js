var searchData=
[
  ['automode',['AutoMode',['../classvisiontransfer_1_1DeviceParameters.html#a1246b8238726ddbda93296e6f885e80d',1,'visiontransfer::DeviceParameters']]]
];
