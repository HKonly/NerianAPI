var searchData=
[
  ['manual_5fexposore_5fauto_5fgain',['MANUAL_EXPOSORE_AUTO_GAIN',['../classvisiontransfer_1_1DeviceParameters.html#a1246b8238726ddbda93296e6f885e80da096909c72cf26279219a977f39cecf2a',1,'visiontransfer::DeviceParameters']]],
  ['manual_5fexposure_5fmanual_5fgain',['MANUAL_EXPOSURE_MANUAL_GAIN',['../classvisiontransfer_1_1DeviceParameters.html#a1246b8238726ddbda93296e6f885e80da0000dabc6bb87fd846470c0df5c54eeb',1,'visiontransfer::DeviceParameters']]]
];
