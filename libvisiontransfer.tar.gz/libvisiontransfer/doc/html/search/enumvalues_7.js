var searchData=
[
  ['rectify',['RECTIFY',['../classvisiontransfer_1_1DeviceParameters.html#ab70aa27a776bc19fc81e9b63016ab700aa8ec86815b75ebfcb870a3ea6e88bc7c',1,'visiontransfer::DeviceParameters']]],
  ['right_5fframe',['RIGHT_FRAME',['../classvisiontransfer_1_1DeviceParameters.html#ae1d20a87d9e1eee7d08f4c5fd03cde02a7194156d482a1ef6a812b326244e7099',1,'visiontransfer::DeviceParameters']]]
];
