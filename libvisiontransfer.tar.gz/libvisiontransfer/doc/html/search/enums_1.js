var searchData=
[
  ['imageformat',['ImageFormat',['../classvisiontransfer_1_1ImageSet.html#a01f3573d250c4dcee32809375b28abba',1,'visiontransfer::ImageSet']]],
  ['imageformat_5fdeprecated',['ImageFormat_Deprecated',['../classvisiontransfer_1_1ImageSet.html#ac876f21503bbd4d87b8ba87dafdfac15',1,'visiontransfer::ImageSet']]],
  ['imagetype',['ImageType',['../classvisiontransfer_1_1ImageSet.html#ae89b2e9ec90ccef34640274291d7400e',1,'visiontransfer::ImageSet']]]
];
