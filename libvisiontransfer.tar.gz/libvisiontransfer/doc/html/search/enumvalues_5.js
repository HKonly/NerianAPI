var searchData=
[
  ['no_5fvalid_5fdata',['NO_VALID_DATA',['../classvisiontransfer_1_1ImageTransfer.html#ab3580eab2dae0695d353cf6626d5e5a7a59b399387a63e9cd0c592e903d40cd64',1,'visiontransfer::ImageTransfer']]],
  ['not_5fconnected',['NOT_CONNECTED',['../classvisiontransfer_1_1ImageTransfer.html#ab3580eab2dae0695d353cf6626d5e5a7ab56fc3e1b17fa514c7772f57df91a51e',1,'visiontransfer::ImageTransfer']]]
];
