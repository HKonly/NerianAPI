var searchData=
[
  ['newclientconnected',['newClientConnected',['../classvisiontransfer_1_1internal_1_1DataBlockProtocol.html#a51f8ac794959fbfebd7885795b14964c',1,'visiontransfer::internal::DataBlockProtocol::newClientConnected()'],['../classvisiontransfer_1_1ImageProtocol.html#adf3d92c0446a5d614089239af283fcce',1,'visiontransfer::ImageProtocol::newClientConnected()']]]
];
