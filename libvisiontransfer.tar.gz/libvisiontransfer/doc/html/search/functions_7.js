var searchData=
[
  ['operator_3d_3d',['operator==',['../classvisiontransfer_1_1DeviceInfo.html#a516e439fe0222342c95a69d45cc6b0ea',1,'visiontransfer::DeviceInfo']]]
];
