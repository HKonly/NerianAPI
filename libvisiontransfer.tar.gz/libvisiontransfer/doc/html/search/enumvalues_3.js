var searchData=
[
  ['left_5fframe',['LEFT_FRAME',['../classvisiontransfer_1_1DeviceParameters.html#ae1d20a87d9e1eee7d08f4c5fd03cde02ac9c88c4eb3e9964b6d4a22e73627ce7c',1,'visiontransfer::DeviceParameters']]]
];
