var searchData=
[
  ['operationmode',['OperationMode',['../classvisiontransfer_1_1DeviceParameters.html#ab70aa27a776bc19fc81e9b63016ab700',1,'visiontransfer::DeviceParameters']]]
];
