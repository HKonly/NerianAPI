var searchData=
[
  ['accuracy',['accuracy',['../classvisiontransfer_1_1TimestampedQuaternion.html#aab9e074a2e09abf39716e8dbfbc2f104',1,'visiontransfer::TimestampedQuaternion']]],
  ['asynctransfer',['AsyncTransfer',['../classvisiontransfer_1_1AsyncTransfer.html#aa9e1a9f82242266cce9c69217997b228',1,'visiontransfer::AsyncTransfer::AsyncTransfer(const char *address, const char *service=&quot;7681&quot;, ImageProtocol::ProtocolType protType=ImageProtocol::PROTOCOL_UDP, bool server=false, int bufferSize=16 *1048576, int maxUdpPacketSize=1472)'],['../classvisiontransfer_1_1AsyncTransfer.html#aa164cf86e8f6709c20c1e70a53327cf7',1,'visiontransfer::AsyncTransfer::AsyncTransfer(const DeviceInfo &amp;device, int bufferSize=1048576, int maxUdpPacketSize=1472)']]]
];
