var searchData=
[
  ['bitconversions',['BitConversions',['../classvisiontransfer_1_1internal_1_1BitConversions.html',1,'visiontransfer::internal']]],
  ['both_5fframes',['BOTH_FRAMES',['../classvisiontransfer_1_1DeviceParameters.html#ae1d20a87d9e1eee7d08f4c5fd03cde02a1d54a052636bc5e5f4fbc93880a59b95',1,'visiontransfer::DeviceParameters']]]
];
