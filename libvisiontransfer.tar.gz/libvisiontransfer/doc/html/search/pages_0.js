var searchData=
[
  ['changelog_20for_20nerian_20vision_20software_20release',['Changelog for Nerian Vision Software Release',['../md_CHANGELOG.html',1,'']]]
];
