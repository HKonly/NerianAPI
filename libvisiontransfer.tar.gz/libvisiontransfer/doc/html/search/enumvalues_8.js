var searchData=
[
  ['stereo_5fmatching',['STEREO_MATCHING',['../classvisiontransfer_1_1DeviceParameters.html#ab70aa27a776bc19fc81e9b63016ab700a117db6a8259f0fe94ceae3fe608fd3a7',1,'visiontransfer::DeviceParameters']]]
];
