var searchData=
[
  ['would_5fblock',['WOULD_BLOCK',['../classvisiontransfer_1_1ImageTransfer.html#ab3580eab2dae0695d353cf6626d5e5a7a462c544065266be4297fb2f05c92da8a',1,'visiontransfer::ImageTransfer']]]
];
