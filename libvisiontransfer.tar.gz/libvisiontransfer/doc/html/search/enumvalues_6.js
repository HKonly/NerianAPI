var searchData=
[
  ['partial_5ftransfer',['PARTIAL_TRANSFER',['../classvisiontransfer_1_1ImageTransfer.html#ab3580eab2dae0695d353cf6626d5e5a7acd0cabc474074d6bcac5b3b0f7b43fde',1,'visiontransfer::ImageTransfer']]],
  ['pass_5fthrough',['PASS_THROUGH',['../classvisiontransfer_1_1DeviceParameters.html#ab70aa27a776bc19fc81e9b63016ab700a02766e8113a25503e643c00383840bc3',1,'visiontransfer::DeviceParameters']]],
  ['protocol_5ftcp',['PROTOCOL_TCP',['../classvisiontransfer_1_1ImageProtocol.html#a797817081629c3edcc1f9f43c6a0ca45ab17ffce09be3f63b9376cdd76e4179e2',1,'visiontransfer::ImageProtocol']]],
  ['protocol_5fudp',['PROTOCOL_UDP',['../classvisiontransfer_1_1ImageProtocol.html#a797817081629c3edcc1f9f43c6a0ca45a682786aac8c238e7f784506f7b7ecc7e',1,'visiontransfer::ImageProtocol']]]
];
