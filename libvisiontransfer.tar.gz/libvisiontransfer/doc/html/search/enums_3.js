var searchData=
[
  ['protocoltype',['ProtocolType',['../classvisiontransfer_1_1ImageProtocol.html#a797817081629c3edcc1f9f43c6a0ca45',1,'visiontransfer::ImageProtocol']]]
];
